export const courts = [
  { id: 1, name: "Cancha 1 - Césped Sintético", price: 5000 },
  { id: 2, name: "Cancha 2 - Blindex Premium", price: 5500 },
  { id: 3, name: "Cancha 3 - Techada", price: 6000 }
];
