import React from "react";

export default function Home({ goToBooking }) {
  return (
    <section className="px-4 pt-10 pb-16 max-w-6xl mx-auto">
      <div className="grid lg:grid-cols-2 gap-10 items-center">
        <div>
          <p className="text-lime-400 text-xs font-semibold tracking-wide uppercase mb-3">
            Gestión de turnos en vivo
          </p>

          <h1 className="text-4xl sm:text-5xl font-bold text-white leading-tight">
            Reservá tu cancha de pádel <span className="text-lime-400">ahora</span>.
          </h1>

          <p className="text-neutral-400 text-base sm:text-lg mt-4 max-w-lg">
            Calendario online, disponibilidad en tiempo real, confirmación
            instantánea. Todo desde el celular. Sin llamados. Sin drama.
          </p>

          <div className="flex flex-col sm:flex-row gap-3 mt-8">
            <button
              onClick={goToBooking}
              className="bg-lime-400 text-neutral-900 text-sm font-semibold px-5 py-3 rounded-xl shadow-[0_0_20px_rgba(163,230,53,0.6)] hover:scale-[1.03] active:scale-[0.98] transition w-full sm:w-auto text-center"
            >
              Reservar Turno
            </button>

            <a
              href="#beneficios"
              className="bg-neutral-900/60 border border-neutral-700 text-white text-sm font-semibold px-5 py-3 rounded-xl hover:border-lime-400 hover:text-lime-400 transition w-full sm:w-auto text-center"
            >
              ¿Por qué elegirnos?
            </a>
          </div>
        </div>

        {/* Preview tipo celular */}
        <div className="relative flex justify-center">
          <div className="w-[220px] sm:w-[260px] rounded-2xl border border-neutral-700 bg-neutral-900/60 p-4 shadow-[0_0_60px_rgba(163,230,53,0.2)]">
            <div className="text-xs text-neutral-400 mb-2">Próximos turnos</div>
            <div className="space-y-2 text-xs">
              <div className="bg-neutral-800/60 border border-neutral-700 rounded-lg p-2">
                <div className="flex justify-between text-white">
                  <span>Cancha 2</span>
                  <span className="text-lime-400 font-semibold">19:00</span>
                </div>
                <div className="text-[10px] text-neutral-500">Hoy • $5500</div>
              </div>

              <div className="bg-neutral-800/60 border border-neutral-700 rounded-lg p-2">
                <div className="flex justify-between text-white">
                  <span>Cancha 1</span>
                  <span className="text-lime-400 font-semibold">20:00</span>
                </div>
                <div className="text-[10px] text-neutral-500">Hoy • $5000</div>
              </div>

              <div className="bg-neutral-800/60 border border-neutral-700 rounded-lg p-2">
                <div className="flex justify-between text-white">
                  <span>Cancha 3</span>
                  <span className="text-lime-400 font-semibold">21:00</span>
                </div>
                <div className="text-[10px] text-neutral-500">
                  Techada • $6000
                </div>
              </div>
            </div>

            <div className="text-[10px] text-center text-neutral-600 mt-4">
              vista previa
            </div>
          </div>
        </div>
      </div>

      <div id="beneficios" className="mt-20 grid md:grid-cols-3 gap-6">
        <div className="bg-neutral-900/40 border border-neutral-800 rounded-xl p-5">
          <div className="text-white font-semibold text-lg leading-tight">
            Calendario en tiempo real
          </div>
          <div className="text-neutral-400 text-sm mt-2">
            El jugador ve horarios libres y reserva al toque. Sin mensajes,
            sin Excel.
          </div>
        </div>

        <div className="bg-neutral-900/40 border border-neutral-800 rounded-xl p-5">
          <div className="text-white font-semibold text-lg leading-tight">
            Múltiples canchas
          </div>
          <div className="text-neutral-400 text-sm mt-2">
            Mostrá todas tus canchas y sus precios en una sola vista clara.
          </div>
        </div>

        <div className="bg-neutral-900/40 border border-neutral-800 rounded-xl p-5">
          <div className="text-white font-semibold text-lg leading-tight">
            Gestión del club
          </div>
          <div className="text-neutral-400 text-sm mt-2">
            Panel para admins: control de agenda, cancelaciones y estados.
          </div>
        </div>
      </div>
    </section>
  );
}
