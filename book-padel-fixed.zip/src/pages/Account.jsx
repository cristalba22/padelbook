import React from "react";
import { useAuth } from "../hooks/useAuth.jsx";

export default function Account() {
  const { user } = useAuth();

  if (!user) {
    return (
      <section className="px-4 py-16 max-w-xl mx-auto text-center">
        <h2 className="text-white font-bold text-2xl">Ingresá</h2>
        <p className="text-neutral-500 text-sm mt-2">
          Necesitás iniciar sesión cuando confirmás un turno.
        </p>
        <p className="text-neutral-600 text-xs mt-6">
          Tip: vas a poder iniciar sesión desde el popup cuando confirmes una
          reserva.
        </p>
      </section>
    );
  }

  return (
    <section className="px-4 py-16 max-w-xl mx-auto">
      <h2 className="text-white font-bold text-2xl">
        Hola {user.name} 👋
      </h2>
      <div className="text-neutral-400 text-sm mt-2">{user.email}</div>
      <div className="text-neutral-400 text-sm">Tel: {user.phone}</div>

      <div className="bg-neutral-900/40 border border-neutral-800 rounded-xl p-5 mt-8 text-sm text-neutral-300">
        <div className="font-semibold text-white mb-2">
          Tus próximas reservas
        </div>

        <div className="flex items-center justify-between py-2 border-b border-neutral-800 text-xs">
          <span>Cancha 2 • 2025-10-28 • 19:00</span>
          <span className="text-lime-400 font-semibold">$5500</span>
        </div>

        <div className="flex items-center justify-between py-2 text-xs">
          <span>Cancha 3 • 2025-10-30 • 21:00</span>
          <span className="text-lime-400 font-semibold">$6000</span>
        </div>
      </div>
    </section>
  );
}
