import React from "react";
import DatePicker from "../components/DatePicker.jsx";
import CourtAvailability from "../components/CourtAvailability.jsx";
import BookingSummary from "../components/BookingSummary.jsx";
import { useBooking } from "../hooks/useBooking.jsx";

export default function Booking() {
  const { selectedDate } = useBooking();

  return (
    <section className="px-4 py-10 max-w-6xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
        <div>
          <h2 className="text-white font-bold text-2xl leading-tight">
            Reservar turno
          </h2>
          <p className="text-neutral-500 text-sm max-w-md mt-1">
            Elegí fecha, cancha y horario disponible. Confirmás en un toque.
          </p>
        </div>

        <div className="w-full max-w-xs">
          <DatePicker />
        </div>
      </div>

      <div className="text-[11px] text-neutral-600 mt-2">
        Fecha seleccionada:{" "}
        <span className="text-neutral-300">{selectedDate}</span>
      </div>

      <CourtAvailability />

      <div className="mt-10 max-w-md ml-auto">
        <BookingSummary />
      </div>
    </section>
  );
}
