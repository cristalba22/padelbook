import React, { useState } from "react";
import Header from "./components/Header.jsx";
import Footer from "./components/Footer.jsx";
import Home from "./pages/Home.jsx";
import Booking from "./pages/Booking.jsx";
import Account from "./pages/Account.jsx";
import Admin from "./pages/Admin.jsx";
import { AuthProvider } from "./hooks/useAuth.jsx";
import { BookingProvider } from "./hooks/useBooking.jsx";

export default function App() {
  const [currentPage, setCurrentPage] = useState("home");

  function renderPage() {
    if (currentPage === "booking") return <Booking />;
    if (currentPage === "account") return <Account />;
    if (currentPage === "admin") return <Admin />;
    return <Home goToBooking={() => setCurrentPage("booking")} />;
  }

  return (
    <AuthProvider>
      <BookingProvider>
        <div className="min-h-screen bg-neutral-950 text-white flex flex-col">
          <Header currentPage={currentPage} onNavigate={setCurrentPage} />
          <main className="flex-1">{renderPage()}</main>
          <Footer />
        </div>
      </BookingProvider>
    </AuthProvider>
  );
}
