import React from "react";
import { useAuth } from "../hooks/useAuth.jsx";

export default function Header({ currentPage, onNavigate }) {
  const { user, logout } = useAuth();

  return (
    <header className="border-b border-neutral-800 bg-neutral-950/80 backdrop-blur sticky top-0 z-50">
      <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between px-4 py-4 gap-3">

        {/* Logo */}
        <div
          className="flex items-center gap-2 cursor-pointer"
          onClick={() => onNavigate("home")}
        >
          <div className="w-9 h-9 rounded-xl bg-lime-400 text-neutral-900 font-bold flex items-center justify-center text-xs leading-none shadow-[0_0_20px_rgba(163,230,53,0.6)]">
            <span className="text-center">
              BK<br/>PDL
            </span>
          </div>
          <div className="text-left">
            <div className="text-white font-semibold leading-none">
              Book Padel
            </div>
            <div className="text-[11px] text-neutral-400 leading-none">
              Gestión de turnos
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex flex-wrap items-center gap-4 text-sm text-neutral-300">
          <button
            className={`hover:text-white ${currentPage === "home" ? "text-white font-medium" : ""}`}
            onClick={() => onNavigate("home")}
          >
            Inicio
          </button>

          <button
            className={`hover:text-white ${currentPage === "booking" ? "text-white font-medium" : ""}`}
            onClick={() => onNavigate("booking")}
          >
            Reservar
          </button>

          <a className="hover:text-white" href="#beneficios">Beneficios</a>
          <a className="hover:text-white" href="#contacto">Contacto</a>

          {user?.role === "admin" && (
            <button
              className={`hover:text-white ${currentPage === "admin" ? "text-white font-medium" : ""}`}
              onClick={() => onNavigate("admin")}
            >
              Admin
            </button>
          )}

          {user ? (
            <>
              <button
                className={`hover:text-white ${currentPage === "account" ? "text-white font-medium" : ""}`}
                onClick={() => onNavigate("account")}
              >
                Mi Cuenta ({user.name})
              </button>
              <button
                className="text-xs text-neutral-400 hover:text-red-400"
                onClick={logout}
              >
                salir
              </button>
            </>
          ) : (
            <button
              className={`hover:text-white ${currentPage === "account" ? "text-white font-medium" : ""}`}
              onClick={() => onNavigate("account")}
            >
              Ingresar
            </button>
          )}
        </nav>

        {/* CTA */}
        <button
          onClick={() => onNavigate("booking")}
          className="bg-lime-400 text-neutral-900 text-sm font-semibold px-4 py-2 rounded-xl shadow-[0_0_20px_rgba(163,230,53,0.6)] hover:scale-[1.03] active:scale-[0.98] transition"
        >
          EMPEZAR
        </button>
      </div>
    </header>
  );
}
